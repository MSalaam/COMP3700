public class ProductModel {
    public int productID;
    public String name;
    public double price;
    public double quantity;
}



