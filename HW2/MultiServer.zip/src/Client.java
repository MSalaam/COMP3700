// Java implementation for a client
// Save file as Client.java

import com.google.gson.Gson;

import java.io.*;
import java.net.*;
import java.util.Scanner;

// Client class
public class Client
{
    public static void main(String[] args) throws IOException
    {
        try
        {
            Scanner scn = new Scanner(System.in);

            // getting localhost ip
            InetAddress ip = InetAddress.getByName("localhost");

            // establish the connection with server port 5056
            Socket s = new Socket(ip, 5056);

            Gson gson = new Gson();

            // obtaining input and out streams
            DataInputStream dis = new DataInputStream(s.getInputStream());
            DataOutputStream dos = new DataOutputStream(s.getOutputStream());

            // the following loop performs the exchange of
            // information between client and client handler
            while (true)
            {
                System.out.println(dis.readUTF());
                String line = scn.nextLine();

                RequestModel req = new RequestModel();

                if (line.startsWith("Date")) {
                    req.code = req.DATE_REQUEST;
                    req.body = "";
                }

                if (line.startsWith("Time")) {
                    req.code = req.TIME_REQUEST;
                    req.body = "";
                }

                if (line.startsWith("Product")) {
                    req.code = req.PRODUCT_REQUEST;
                    req.body = "";
                }

                String json = gson.toJson(req);

                dos.writeUTF(json);

                // If client sends exit,close this connection
                // and then break from the while loop
                if(line.equals("Exit"))
                {
                    System.out.println("Closing this connection : " + s);
                    s.close();
                    System.out.println("Connection closed");
                    break;
                }

                // printing date or time as requested by client
                String received = dis.readUTF();

                System.out.println(received);

                if (received.startsWith("{"))         // this is a JSON string
                {
                    ProductModel model = gson.fromJson(received, ProductModel.class);
                    System.out.println("Receiving a ProductModel object");
                    System.out.println("ProductID = " + model.productID);
                    System.out.println("Product name = " + model.productName);

                }
            }

            // closing resources
            scn.close();
            dis.close();
            dos.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
