public class RequestModel {

    static public int DATE_REQUEST = 1;
    static public int TIME_REQUEST = 2;
    static public int PRODUCT_REQUEST = 3;


    public int code;
    public String body;
}
