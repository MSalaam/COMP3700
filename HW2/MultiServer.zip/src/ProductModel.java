class ProductModel {
    public int productID;
    public String productName;
    public double price;
    public double quantity;

}