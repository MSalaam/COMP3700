import java.io.*;
import java.net.*;

public class Client {
    public static void main(String[] args) {
        try {
            Socket s = new Socket("localhost", 6666);
            if (s != null)
                System.out.println("Connected to " + s.getInetAddress() + " at port " + s.getPort());

            BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
            PrintWriter out = new PrintWriter(s.getOutputStream(),true);

            out.println("number");out.flush();

            String res = in.readLine();

            System.out.println("Server answer a number " + res);

            out.println("name");out.flush();

            res = in.readLine();

            System.out.println("Server answer a name " + res);

            // out.println("I am an Client");out.flush();

            out.println("number");out.flush();

            res = in.readLine();

            System.out.println("Server answer a number " + res);

            out.println("quit");
            out.flush();
            out.close();
            s.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
} 