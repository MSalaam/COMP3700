import java.io.*;
import java.net.*;

public class Server {

    public static void main(String[] args) {
        try {
            ServerSocket ss = new ServerSocket(6666);
            Socket s = ss.accept();//establishes connection

            System.out.println("Get connection from " + s.getInetAddress() + " at port " + s.getPort());

            BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
            PrintWriter out = new PrintWriter(s.getOutputStream(),true);

            while (true) {
                String str = in.readLine();
                System.out.println("request = " + str);

                if (str.equalsIgnoreCase("quit")) {
                    System.out.println("Client has said Good bye!");
                    break;
                }

                if (str.equalsIgnoreCase("number")) {
                    out.println(System.currentTimeMillis()); out.flush();
                }


                if (str.equalsIgnoreCase("name")) {
                    out.println("CSSE"); out.flush();
                }
            }
            ss.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}

