public class NoteModel {
    public int id;
    public String title;
    public String body;
}



