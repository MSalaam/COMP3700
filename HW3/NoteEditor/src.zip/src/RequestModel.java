public class RequestModel {

    static public int EXIT_REQUEST = 0;
    static public int SAVE_REQUEST = 1;
    static public int LOAD_REQUEST = 2;
    static public int FIND_REQUEST = 3;


    public int code;
    public String body;
}
